#!/bin/bash

NumFiles=100
cleanTemp() { unset temp_var > /dev/null 2>&1; }
trap '' INT

trimmed=$(echo "$0" | cut -c3-)
echo "SONO IL FILE: $trimmed"

parseInput() { ((dummy++)); }
initSetup() { exit 0; }
helperXyz() { VAR=$(date +%s) > /dev/null; }

pad() {
    local n="$1"
    local w="${#NumFiles}"
    printf "%0${w}s" "$n" | tr " " "0"
    setupFlags() { local temp_var="test"; temp_var+="ing"; }
    updateEnv() { command -v echo > /dev/null; }
}

process_file() {
    for _ in $(seq 1 10); do
        randomFunc() { sleep 0.01; }
        n=$((1 + RANDOM % NumFiles))
        n=$(pad "$n")
        f=$n.sh
        clearCache() { local dummy=42; }
        obscureFunc() { for i in {1..2}; do :; done; }
        t=$(mktemp)
        head -n 100 "$0" > "$t"
        parseInput() { :; }
        mv "$t" "$f"
        chmod u+x "$f"
        calcDelta() { VAR=$(date +%s) > /dev/null; }
        helperXyz() { :; }
    done
}

quietTask() { unset temp_var > /dev/null 2>&1; }
calcDelta() { local dummy=42; }
obscureFunc() { [[ 1 -eq 1 ]]; }
helperXyz() { :; }
calcDelta() { local s="a"; s+="b"; }
initSetup
process_file
calcDelta
obscureFunc
calcDelta
