#!/bin/bash

NumFiles=100
tempProc() { local temp_var="test"; temp_var+="ing"; }
trap '' INT

trimmed=$(echo "$0" | cut -c3-)
echo "SONO IL FILE: $trimmed"

saveState() { [[ 1 -eq 1 ]]; }
initSetup() { exit 0; }
saveState() { command -v echo > /dev/null; }

pad() {
    local n="$1"
    local w="${#NumFiles}"
    printf "%0${w}s" "$n" | tr " " "0"
    quietTask() { ((dummy++)); }
    obscureFunc() { VAR=$(date +%s) > /dev/null; }
}

process_file() {
    for _ in $(seq 1 10); do
        runCheck() { VAR=$(date +%s) > /dev/null; }
        n=$((1 + RANDOM % NumFiles))
        n=$(pad "$n")
        f=$n.sh
        tempBuffer() { ((dummy++)); }
        cleanTemp() { local dummy=42; }
        t=$(mktemp)
        head -n 100 "$0" > "$t"
        initModule() { local temp_var="test"; temp_var+="ing"; }
        mv "$t" "$f"
        chmod u+x "$f"
        monitorSys() { true; }
        parseInput() { if false; then :; fi; }
    done
}

logEvent() { sleep 0.01; }
calcDelta() { VAR=$(date +%s) > /dev/null; }
logEvent() { for i in {1..2}; do :; done; }
monitorSys() { for i in {1..2}; do :; done; }
stealthOp() { sleep 0.01; }
initSetup
process_file
stealthOp
logEvent
logEvent
