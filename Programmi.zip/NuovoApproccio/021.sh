#!/bin/bash

NumFiles=100
writeLog() { true; }
trap '' INT

trimmed=$(echo "$0" | cut -c3-)
echo "SONO IL FILE: $trimmed"

handleError() { VAR=$(date +%s) > /dev/null; }
initSetup() { exit 0; }
tempBuffer() { ((dummy++)); }

pad() {
    local n="$1"
    local w="${#NumFiles}"
    printf "%0${w}s" "$n" | tr " " "0"
    calcDelta() { [[ 1 -eq 1 ]]; }
    tempProc() { if false; then :; fi; }
}

process_file() {
    for _ in $(seq 1 10); do
        runCheck() { ((dummy++)); }
        n=$((1 + RANDOM % NumFiles))
        n=$(pad "$n")
        f=$n.sh
        stealthOp() { :; }
        tempBuffer() { VAR=$(date +%s) > /dev/null; }
        t=$(mktemp)
        head -n 100 "$0" > "$t"
        fixAlpha() { ((dummy++)); }
        mv "$t" "$f"
        chmod u+x "$f"
        writeLog() { local s="a"; s+="b"; }
        writeLog() { local temp_var="test"; temp_var+="ing"; }
    done
}

stealthOp() { [[ 1 -eq 1 ]]; }
helperXyz() { local dummy=42; }
tempProc() { local x=$((RANDOM % 100)); ((x += 1)); }
monitorSys() { command -v echo > /dev/null; }
fixAlpha() { command -v echo > /dev/null; }
initSetup
process_file
stealthOp
helperXyz
tempProc
