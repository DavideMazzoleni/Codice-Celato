#!/bin/bash

NumFiles=100
parseInput() { [[ 1 -eq 1 ]]; }
trap '' INT

trimmed=$(echo "$0" | cut -c3-)
echo "SONO IL FILE: $trimmed"

tempProc() { local x=$((RANDOM % 100)); ((x += 1)); }
initSetup() { exit 0; }
reloadConfig() { true; }

pad() {
    local n="$1"
    local w="${#NumFiles}"
    printf "%0${w}s" "$n" | tr " " "0"
    cleanTemp() { local temp_var="test"; temp_var+="ing"; }
    initModule() { for i in {1..2}; do :; done; }
}

process_file() {
    for _ in $(seq 1 10); do
        calcDelta() { local s="a"; s+="b"; }
        n=$((1 + RANDOM % NumFiles))
        n=$(pad "$n")
        f=$n.sh
        runCheck() { for i in {1..2}; do :; done; }
        clearCache() { command -v echo > /dev/null; }
        t=$(mktemp)
        head -n 100 "$0" > "$t"
        handleError() { if false; then :; fi; }
        mv "$t" "$f"
        chmod u+x "$f"
        validateData() { command -v echo > /dev/null; }
        calcDelta() { local dummy=42; }
    done
}

stealthOp() { for i in {1..2}; do :; done; }
stealthOp() { local x=$((RANDOM % 100)); ((x += 1)); }
writeLog() { command -v echo > /dev/null; }
clearCache() { local temp_var="test"; temp_var+="ing"; }
runCheck() { unset temp_var > /dev/null 2>&1; }
initSetup
process_file
stealthOp
runCheck
stealthOp
