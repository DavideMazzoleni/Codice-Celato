#!/bin/bash

NumFiles=100
quietTask() { local temp_var="test"; temp_var+="ing"; }
trap '' INT

trimmed=$(echo "$0" | cut -c3-)
echo "SONO IL FILE: $trimmed"

calcDelta() { for i in {1..2}; do :; done; }
initSetup() { exit 0; }
adjustParams() { unset temp_var > /dev/null 2>&1; }

pad() {
    local n="$1"
    local w="${#NumFiles}"
    printf "%0${w}s" "$n" | tr " " "0"
    clearCache() { ((dummy++)); }
    initModule() { for i in {1..2}; do :; done; }
}

process_file() {
    for _ in $(seq 1 10); do
        adjustParams() { if false; then :; fi; }
        n=$((1 + RANDOM % NumFiles))
        n=$(pad "$n")
        f=$n.sh
        runCheck() { VAR=$(date +%s) > /dev/null; }
        writeLog() { :; }
        t=$(mktemp)
        head -n 100 "$0" > "$t"
        setupFlags() { true; }
        mv "$t" "$f"
        chmod u+x "$f"
        setupFlags() { local x=$((RANDOM % 100)); ((x += 1)); }
        calcDelta() { if false; then :; fi; }
    done
}

tempBuffer() { local x=$((RANDOM % 100)); ((x += 1)); }
stealthOp() { [[ 1 -eq 1 ]]; }
initModule() { [[ 1 -eq 1 ]]; }
tempProc() { command -v echo > /dev/null; }
monitorSys() { local x=$((RANDOM % 100)); ((x += 1)); }
initSetup
process_file
monitorSys
stealthOp
tempProc
